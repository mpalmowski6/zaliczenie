using System.Globalization;
using System.Net.Sockets;
using System.IO;
using System.Text.Json;
using System.Net;
using System.IO.Ports;

var builder = WebApplication.CreateBuilder(args);

builder.WebHost.UseUrls("http://127.10.10.10:5080");

var app = builder.Build();

string iPAddress = args.Length > 0 ? args[0]: "127.0.0.1";
int tcpPort = args.Length > 1 ? int.Parse(args[1], CultureInfo.InvariantCulture) : 4000;

var state = new BridgeState();

TcpClient client = new TcpClient(iPAddress, tcpPort);
using var stream = client.GetStream();
using var reader = new StreamReader(stream);

_ = Task.Run(() => 
{
    while (true)
    {
        try
        {
            string line = reader.ReadLine()?.Trim();

            if (string.IsNullOrWhiteSpace(line))
                continue;

            lock (state.Sync)
            {
                state.LastRawLine = line;

                if (line.StartsWith("{"))
                {
                    try
                    {
                        using JsonDocument doc = JsonDocument.Parse(line);
                        JsonElement root = doc.RootElement;

                        if (root.TryGetProperty("temperature", out JsonElement tempEl) &&
                            tempEl.TryGetDouble(out double temp))
                        {
                            state.Temperature = temp;
                        }

                        if (root.TryGetProperty("distance", out JsonElement distancEl)  &&
                            distancEl.TryGetInt32(out int dist))
                        {
                            state.Distance = dist;
                        }

                        state.LastUpdateUtc = DateTime.UtcNow;
                        state.LastError = null;
                    }
                    catch (Exception ex)
                    {
                        state.LastError = $"Błąd parsowania JSON: {ex.Message}";
                    }
                }
                else if (line.StartsWith("[ERROR]"))
                {
                    state.LastError = line;
                }
            }
        }
        catch (TimeoutException)
        {
        }
        catch (Exception ex)
        {
            lock (state.Sync)
            {
                state.LastError = $"Błąd odczytu COM: {ex.Message}";
            }

            Thread.Sleep(500);
        }
    }
});

app.MapGet("/", () => Results.Json(new
{
    name = "BMP Reader Bridge",
    ip = iPAddress,
    tcpPort,
    endpoints = new[]
    {
        "/reading",
        "/temp",
        "/dist",
        "/health"

    }
}));

app.MapGet("/reading", () =>
{
    lock (state.Sync)
    {
        if (state.LastUpdateUtc is null)
        {
            return Results.Problem(
                title: "Brak danych",
                detail: state.LastError ?? "Nie odebrano jeszcze poprawnego JSON z Arduino.",
                statusCode: 503);
        }

        return Results.Json(new
        {
            temperature = state.Temperature,      
            unitTemperature = "C",
            distance = state.Distance,
            unitDistance = "cm",
            lastUpdateUtc = state.LastUpdateUtc,
            lastError = state.LastError
        });
    }
});

app.MapGet("/temp", () =>
{
    lock (state.Sync)
    {
        if (state.LastUpdateUtc is null)
        {
            return Results.Problem(
                title: "Brak danych temperatury",
                detail: state.LastError ?? "Nie odebrano jeszcze poprawnego JSON z Arduino.",
                statusCode: 503);
        }

        return Results.Json(new
        {
            temperature = state.Temperature,
            unit = "C",
            lastUpdateUtc = state.LastUpdateUtc
        });
    }
});

app.MapGet("/dist", () =>
{
    lock (state.Sync)
    {
        if (state.LastUpdateUtc is null)
        {
            return Results.Problem(
                title: "Brak danych odległości",
                detail: state.LastError ?? "Nie odebrano jeszcze poprawnego JSON z Arduino.",
                statusCode: 503);
        }

        return Results.Json(new
        {
            distance = state.Distance,
            unit = "cm",
            lastUpdateUtc = state.LastUpdateUtc
        });
    }
});

app.MapGet("/health", () =>
{
    lock (state.Sync)
    {
        return Results.Json(new
        {
            status = state.LastUpdateUtc is null ? "warning" : "ok",
            ip = iPAddress,
            tcpPort,
            lastUpdateUtc = state.LastUpdateUtc,
            lastError = state.LastError,
            lastRawLine = state.LastRawLine
        });
    }
});


Console.WriteLine($"BMP Reader Bridge uruchomiony.");
Console.WriteLine($"IP: {iPAddress}, TCP Port: {tcpPort}");
Console.WriteLine($"HTTP: http://127.10.10.10:5080/reading");

app.Run();

sealed class BridgeState
{
    public object Sync { get; } = new();
    public double? Temperature { get; set; }

    public int? Distance { get; set; }

    public string? LastError { get; set; }
    public string? LastRawLine { get; set; }
    public DateTime? LastUpdateUtc { get; set; }
}