#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_BMP085.h>
#include <ArduinoJson.h>
#include <HCSR04.h>

JsonDocument jsonDoc;

Adafruit_BMP085 bmp;
HCSR04 hcsr(19,18);

bool bmpReady = false;
bool hcsrReady = false;
int testDistance;

void setup() {

    Serial.begin(115200);

    delay(300);

    Wire.begin(21, 22);
    
    bmpReady = bmp.begin();

    testDistance = hcsr.dist();

    if (!bmpReady) {
        Serial.println("[ERROR] Nie znaleziono sensora BMP180. Sprawdz okablowanie i zasilanie.");
    }

    if(!hcsrReady) {
        Serial.println("[ERROR] Nie znaleziono sensora HCSR04. Sprawdz okablowanie i zasilanie.");
    }
    
    if(testDistance > 0 && testDistance < 400) {
        hcsrReady = true;
    }
    
    if(!hcsrReady){
        Serial.println("[ERROR] Nie znaleziono sensora HCSR04. Sprawdz okablowanie i zasilanie.");
    }

}

void loop() {

    if (!bmpReady) {
        Serial.println("[ERROR] Brak komunikacji z BMP180.");
        delay(2000);
        return;
    }
    if (!hcsrReady){
        Serial.println("[ERROR] Brak komunikacji z HCSR04.");
        testDistance = hcsr.dist();
        if(testDistance > 0 && testDistance < 400) {
        hcsrReady = true;
        }
        delay(2000);
        return;
    }

    float temperature = bmp.readTemperature();

    int distance = hcsr.dist();

    jsonDoc["temperature"] = temperature;
    jsonDoc["distance"] = distance;

    serializeJson(jsonDoc, Serial);

    Serial.println();

    delay(500);
}