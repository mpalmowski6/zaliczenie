#pragma once
#include <Arduino.h>

class EventTimer {
public:
    EventTimer() : startMs(0), running(false) {}

    // Wywołuj regularnie z aktualnym warunkiem (true = zdarzenie trwa)
    void update(bool condition) {
        if (condition) {
            if (!running) {
                running = true;
                startMs = millis();
            }
        } else {
            running = false;
            startMs = 0;
        }
    }

    // Czas trwania zdarzenia w ms (0 gdy nieaktywne)
    unsigned long elapsed() const {
        if (!running) return 0;
        return millis() - startMs;
    }

    // Czy zdarzenie trwa co najmniej podany próg (ms)
    bool elapsedAtLeast(unsigned long ms) const {
        return running && (millis() - startMs) >= ms;
    }

    void reset() {
        running = false;
        startMs = 0;
    }

    bool isRunning() const { return running; }

private:
    unsigned long startMs;
    bool running;
};
