﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Client
{
   
        public class SensorReading
        {
            public double Temperature { get; set; }
            public string UnitTemperature { get; set; }
            public int Distance { get; set; }
            public string UnitDistance { get; set; }
            public DateTime LastUpdateUtc { get; set; }
            public string LastError { get; set; }

        }
   
}
