﻿using Client;
using System;
using System.Diagnostics;
using System.Net.Http.Json;
using System.Reflection;
using System.Xml.Schema;

const int MINUTA = 60000;

Stopwatch stopwatch = new();

HttpClient client = new();
string analysisEvent = null;
bool criticalEvent = false;

while (true)
{
    try
    {
        var reading = await client.GetFromJsonAsync<SensorReading>(
            "http://127.10.10.10:5080/reading");
        Console.WriteLine($"Temp: {reading?.Temperature}{reading?.UnitTemperature}");
        Console.WriteLine($"Distance: {reading?.Distance}{reading?.UnitDistance}");
        if (reading != null)
        {
            if (!criticalEvent)
            {
                string newEvent = Analyzer.Analyze(reading);

                if (string.Equals(newEvent, "Critical Incident", StringComparison.OrdinalIgnoreCase))
                {
                    criticalEvent = true;
                    stopwatch.Reset();
                    analysisEvent = newEvent;
                }
                else if (string.Equals(newEvent, "Security Event", StringComparison.OrdinalIgnoreCase))
                {
                    analysisEvent = newEvent;
                    stopwatch.Reset(); 
                }
                else 
                {
                    if (!stopwatch.IsRunning)
                        stopwatch.Restart(); 

                    if (stopwatch.ElapsedMilliseconds >= MINUTA)
                    {
                        analysisEvent = null;
                        stopwatch.Reset();
                    }
                }
            }

        }
            Console.WriteLine($"Event: {analysisEvent}");
        await Task.Delay(1000);
    }
    catch(Exception ex)
    {
        Console.Clear();
        Console.WriteLine($"Error: {ex.Message}");
        await Task.Delay(2000);
    }
}