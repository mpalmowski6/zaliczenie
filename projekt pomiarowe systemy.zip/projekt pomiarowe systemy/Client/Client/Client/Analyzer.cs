﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Client
{
    public static class Analyzer
    {
        public static string Analyze(SensorReading reading)
        {
            double temp = reading.Temperature;
            int distance = reading.Distance;
            bool temperatureAlert = temp < 2 || temp > 8;
            bool distanceAlert = distance > 10;
            string criticalIncident = null;
            
            if (temperatureAlert && distanceAlert)
            {
                criticalIncident = "Critical Incident";
            }
            else if ((temperatureAlert || distanceAlert))
            {
                criticalIncident = ("Security Event");
            }
           
            return criticalIncident; 
        }
    }
}

